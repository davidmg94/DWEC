$(function(){

  console.log($);
});

window.addEventListener("load", function(){
  console.log("Inicio");

  // Creamos un objeto URL para la base de la API de Star Wars
  const baseUrl = new URL('http://localhost/exam/php/getEmployee.php');
  // Agregamos el endpoint para obtener la lista de películas
  const filmsEndpoint = 'films/'; // Elegimos elegimos el path de búsqueda para películas.
  // Creamos una nueva URL con el endpoint de películas
  const filmsUrl = new URL(filmsEndpoint, baseUrl);
  filmsUrl.searchParams.set('search', 'Jedi'); // Fijamos parámetros de búsqueda
  console.log(baseUrl.toString()); // https://swapi.dev/api/films/?search=Jedi

  fetch('./php/getEmployee.php') // Hacer una solicitud GET a la API con la ruta de la película "A New Hope"
  .then(response => response.json()) // Analizar la respuesta JSON
  .then(data => {    
    let results = data.results; // Obtenemos el array de búsqueda  
    console.log(data); // 1. Solamente un único resultado obtenido
  })
  .catch(error => console.error(error)); // Manejar errores    
})