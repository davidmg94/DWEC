$(function(){

  console.log($);
});





