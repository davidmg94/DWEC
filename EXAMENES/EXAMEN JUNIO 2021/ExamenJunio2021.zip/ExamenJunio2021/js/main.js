
(function ($) {
    "use strict";

    $("#basket").click(function () {
        $("#tennisForm").hide();
        $("#basketForm").show();
    });

    $("#tennis").click(function () {
        $("#basketForm").hide();
        $("#tennisForm").show();
    });



})(jQuery);