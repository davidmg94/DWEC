# MiTienda

## Versiones

### 1.2
- Sintaxis y operadores
- Juego del BlackJack
- Expresiones Regulares
- Colecciones
- Symbol
  
### 1.1
- Tutorial básico
- Ejemplos de implementación FizzBuzz

### 1.0
- HTML inicial
